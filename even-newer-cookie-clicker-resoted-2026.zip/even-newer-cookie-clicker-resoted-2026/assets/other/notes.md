# notes:
- This will forever be a work in progress so be aware that it changes very often.
- Sorry if you have to compress the github file manualy but we don't have control over that so please don't blame us.
- This project has light sequens that may cause sensitive users to have stroke so please don't blame us for that either.
- The apple coders is a repl team so this was not made by an individual person
- Sadly we will only add holiday versions oncee it is in the month of the holiday so be aware of that please.

-Thanks
the @AppleCoders (multiteam)