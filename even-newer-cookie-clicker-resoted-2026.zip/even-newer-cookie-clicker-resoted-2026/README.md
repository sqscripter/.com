# Cookie Clicker
## **PLEASE READ THIS OR THE GAME WON'T WORK!!**

TO RUN THE GAME:

1. Right-Click the **index.html** file.
2. Click "Open With.." and choose Google Chrome (or other specified Web Browsers like Safari, Firefox, Opera, etc.)


That is all!
--------------------------------------------------


Credits:

DaxCodes/DaRedDeveloper: https://replit.com/@DaxCodes

sqcodes: https://replit.com/@sqcodes

# Extra Cookie Content 😉: https://replit.com/@DaxCodes/Hacked-Cookie-Clicker?v=1

#### open that extra content in a new tab for other content that we were thinkin about buuut never made it in lol.

---------------

## Cookie Code Streams

We will possibly start streaming on YouTube on how we make Cookie Clicker!

Channel Link: https://www.youtube.com/channel/UC0nPLeSIqTrynkW5JM0TlGA

